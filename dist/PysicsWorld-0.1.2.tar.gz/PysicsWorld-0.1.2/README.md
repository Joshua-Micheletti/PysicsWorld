# PysicsWorld

A 2D physics engine that handles AABB rect vs rect collision detection and resolution
